create view viewbaivietchitiet as
select `qlwebdulich`.`baiviet`.`id`                                              AS `id`,
       `qlwebdulich`.`baiviet`.`TenBaiViet`                                      AS `TenBaiViet`,
       `qlwebdulich`.`baiviet`.`TomTat`                                          AS `TomTat`,
       `qlwebdulich`.`baiviet`.`NoiDung`                                         AS `NoiDung`,
       `qlwebdulich`.`baiviet`.`Code`                                            AS `Code`,
       `qlwebdulich`.`baiviet`.`AnhDaiDien`                                      AS `AnhDaiDien`,
       `qlwebdulich`.`baiviet`.`ThoiGianDang`                                    AS `ThoiGianDang`,
       `qlwebdulich`.`baiviet`.`ThoiGianChinhSua`                                AS `ThoiGianChinhSua`,
       `qlwebdulich`.`baiviet`.`NguoiDang_id`                                    AS `NguoiDang_id`,
       `qlwebdulich`.`baiviet`.`NguoiSua_id`                                     AS `NguoiSua_id`,
       `qlwebdulich`.`baiviet`.`XuatBan`                                         AS `XuatBan`,
       `qlwebdulich`.`baiviet`.`NoiBat`                                          AS `NoiBat`,
       `qlwebdulich`.`baiviet`.`NhanVatLichSu_id`                                AS `NhanVatLichSu_id`,
       `qlwebdulich`.`baiviet`.`LangNghe_id`                                     AS `LangNghe_id`,
       `qlwebdulich`.`baiviet`.`LeHoi_id`                                        AS `LeHoi_id`,
       `qlwebdulich`.`baiviet`.`DiaDanh_id`                                      AS `DiaDanh_id`,
       `qlwebdulich`.`baiviet`.`Title`                                           AS `Title`,
       `qlwebdulich`.`baiviet`.`Alt`                                             AS `Alt`,
       `qlwebdulich`.`baiviet`.`Like`                                            AS `Like`,
       (select count(0)
        from `qlwebdulich`.`likes`
        where `qlwebdulich`.`likes`.`BaiViet_id` = `qlwebdulich`.`baiviet`.`id`) AS `liked`,
       `qlwebdulich`.`baivietdanhmuc`.`BaiViet_id`                               AS `BaiViet_id`,
       `qlwebdulich`.`danhmuc`.`id`                                              AS `Danhmuc_id`,
       `qlwebdulich`.`danhmuc`.`TenDanhMuc`                                      AS `TenDanhMuc`,
       `qlwebdulich`.`diadanh`.`TenDiaDanh`                                      AS `TenDiaDanh`,
       `qlwebdulich`.`quanhuyen`.`TenQuanHuyen`                                  AS `TenQuanHuyen`,
       `qlwebdulich`.`capcongnhan`.`id`                                          AS `CapCongNhan_id`,
       `qlwebdulich`.`capcongnhan`.`TenCapCongNhan`                              AS `TenCapCongNhan`,
       `qlwebdulich`.`loaiditich`.`id`                                           AS `LoaiDiTich_id`,
       `qlwebdulich`.`loaiditich`.`TenLoaiDiTich`                                AS `TenLoaiDiTich`
from (((((((`qlwebdulich`.`baiviet` join `qlwebdulich`.`baivietdanhmuc` on (`qlwebdulich`.`baiviet`.`id` =
                                                                            `qlwebdulich`.`baivietdanhmuc`.`BaiViet_id`)) join `qlwebdulich`.`danhmuc` on (
        `qlwebdulich`.`danhmuc`.`id` =
        `qlwebdulich`.`baivietdanhmuc`.`DanhMuc_id`)) left join `qlwebdulich`.`diadanh` on (`qlwebdulich`.`baiviet`.`DiaDanh_id` = `qlwebdulich`.`diadanh`.`id`)) left join `qlwebdulich`.`quanhuyen` on (
        `qlwebdulich`.`diadanh`.`QuanHuyen_id` =
        `qlwebdulich`.`quanhuyen`.`id`)) left join `qlwebdulich`.`langnghe` on (`qlwebdulich`.`baiviet`.`LangNghe_id` = `qlwebdulich`.`langnghe`.`id`)) left join `qlwebdulich`.`capcongnhan` on (
        `qlwebdulich`.`diadanh`.`CapCongNhan_id` = `qlwebdulich`.`capcongnhan`.`id`))
         left join `qlwebdulich`.`loaiditich`
                   on (`qlwebdulich`.`diadanh`.`LoaiDiTich_id` = `qlwebdulich`.`loaiditich`.`id`));

