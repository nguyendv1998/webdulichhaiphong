create definer = dulichhaiphong@localhost view viewselectdanhmuc as
select `qlwebdulich`.`danhmuc`.`id`            AS `id`,
       `qlwebdulich`.`danhmuc`.`TenDanhMuc`    AS `TenDanhMuc`,
       `qlwebdulich`.`danhmuc`.`Code`          AS `Code`,
       `qlwebdulich`.`danhmuc`.`DanhMucCha_id` AS `DanhMucCha_id`
from `qlwebdulich`.`danhmuc`
where `qlwebdulich`.`danhmuc`.`DanhMucCha_id` is null and
      !(`qlwebdulich`.`danhmuc`.`id` in (select distinct `qlwebdulich`.`danhmuc`.`DanhMucCha_id`
                                         from `qlwebdulich`.`danhmuc`
                                         where `qlwebdulich`.`danhmuc`.`DanhMucCha_id` is not null))
   or !(`qlwebdulich`.`danhmuc`.`id` in (select distinct `qlwebdulich`.`danhmuc`.`DanhMucCha_id`
                                         from `qlwebdulich`.`danhmuc`
                                         where `qlwebdulich`.`danhmuc`.`DanhMucCha_id` is not null));

