<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tukhoa".
 *
 * @property int $id
 * @property string|null $TenTuKhoa
 * @property string|null $Code
 *
 * @property TuKhoaChiTiet[] $tukhoachitiets
 */
class TuKhoa extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tukhoa';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['TenTuKhoa', 'Code'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'TenTuKhoa' => 'Ten Tu Khoa',
            'Code' => 'Code',
        ];
    }

    /**
     * Gets query for [[Tukhoachitiets]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTukhoachitiets()
    {
        return $this->hasMany(TuKhoaChiTiet::className(), ['TuKhoa_id' => 'id']);
    }
}
